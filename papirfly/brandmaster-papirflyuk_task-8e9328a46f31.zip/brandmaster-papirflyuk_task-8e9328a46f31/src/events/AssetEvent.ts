
const NAME: string = "AssetEvent";

export const LOAD_COMPLETE: string = NAME + "LoadComplete";